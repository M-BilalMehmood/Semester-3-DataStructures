#pragma once
#include<iostream>
#include<string>
#include"i222452_SE-B_Hospital.h"
using namespace std;

class Patient {
private:
    string Name;
    string Type;
    int NumDays;
public:
    Patient() {}
    Patient(string name, string type, int numDays) {
        Name = name;
        Type = type;
        NumDays = numDays;
    }
    string getName() {
        return Name;
    }
    string getType() {
        return Type;
    }
    int getNumDays() {
        return NumDays;
    }
};